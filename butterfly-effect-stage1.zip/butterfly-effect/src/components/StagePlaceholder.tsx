import { Hourglass } from 'lucide-react'

export default function StagePlaceholder({ stage, text }: { stage: number; text: string }) {
  return (
    <div className="grid place-items-center rounded-2xl border border-dashed border-edge bg-panel/60 p-12 text-center">
      <Hourglass className="text-haze" size={28} />
      <h2 className="mt-4 font-display text-xl font-semibold">Arrives in Stage {stage}</h2>
      <p className="mt-2 max-w-md text-sm text-slate-400">{text}</p>
    </div>
  )
}
