import type { LucideIcon } from 'lucide-react'

export default function MetricCard({ icon: Icon, label }: { icon: LucideIcon; label: string }) {
  return (
    <div className="rounded-xl border border-edge bg-panel p-4">
      <Icon size={18} className="text-glow" />
      <div className="mt-3 font-display text-2xl font-semibold text-slate-500">--</div>
      <div className="mt-1 text-xs text-slate-400">{label}</div>
    </div>
  )
}
