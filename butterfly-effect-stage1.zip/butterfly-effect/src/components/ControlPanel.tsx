import { SlidersHorizontal } from 'lucide-react'
import type { Controls } from '../types'

interface SliderProps {
  label: string
  hint: string
  value: number
  min: number
  max: number
  unit: string
  onChange: (n: number) => void
}

function Slider({ label, hint, value, min, max, unit, onChange }: SliderProps) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <label className="text-sm font-medium text-slate-200">{label}</label>
        <span className="font-display text-sm text-glow">
          {value > 0 && min < 0 ? '+' : ''}
          {value}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-2 w-full accent-teal-400"
      />
      <p className="mt-1 text-xs text-slate-500">{hint}</p>
    </div>
  )
}

export default function ControlPanel({
  controls,
  onChange,
}: {
  controls: Controls
  onChange: (c: Controls) => void
}) {
  const set = (key: keyof Controls) => (n: number) => onChange({ ...controls, [key]: n })
  return (
    <aside className="h-fit space-y-6 rounded-2xl border border-edge bg-panel p-5">
      <div className="flex items-center gap-2">
        <SlidersHorizontal size={18} className="text-arc" />
        <h2 className="font-display text-lg font-semibold">Decision controls</h2>
      </div>
      <Slider label="Parking spaces removed" hint="Share of the selected lot's spaces taken away." value={controls.parkingRemoved} min={0} max={100} unit="%" onChange={set('parkingRemoved')} />
      <Slider label="Extra buses per hour" hint="New transit service on campus routes." value={controls.extraBuses} min={0} max={20} unit="" onChange={set('extraBuses')} />
      <Slider label="Commuters switching modes" hint="Drivers who move to bus, bike or walking." value={controls.modeShift} min={0} max={50} unit="%" onChange={set('modeShift')} />
      <Slider label="Change in parking demand" hint="Optional shift in how many people want to park." value={controls.demandChange} min={-30} max={30} unit="%" onChange={set('demandChange')} />
      <p className="rounded-lg bg-white/5 p-3 text-xs text-slate-400">
        These sliders save your choices now. In Stage 2 they will drive the simulation.
      </p>
    </aside>
  )
}
