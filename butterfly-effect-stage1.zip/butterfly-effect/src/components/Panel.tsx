import type { ReactNode } from 'react'

export default function Panel({ title, note, children }: { title: string; note: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-edge bg-panel p-5">
      <div className="mb-4 flex items-baseline justify-between gap-3">
        <h2 className="font-display text-lg font-semibold">{title}</h2>
        <span className="text-xs text-slate-500">{note}</span>
      </div>
      {children}
    </section>
  )
}
