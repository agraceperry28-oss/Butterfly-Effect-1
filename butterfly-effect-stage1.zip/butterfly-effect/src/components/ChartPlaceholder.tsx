import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import Panel from './Panel'

// Sample shape only. Real values arrive with the simulation engine in Stage 2.
const SAMPLE = [
  { hour: '7am', pressure: 20 }, { hour: '8am', pressure: 55 }, { hour: '9am', pressure: 80 },
  { hour: '10am', pressure: 70 }, { hour: '11am', pressure: 60 }, { hour: '12pm', pressure: 65 },
  { hour: '1pm', pressure: 58 }, { hour: '2pm', pressure: 45 }, { hour: '3pm', pressure: 30 },
]

export default function ChartPlaceholder() {
  return (
    <Panel title="Congestion pressure through the day" note="Sample curve, not real data">
      <div className="h-56">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={SAMPLE}>
            <defs>
              <linearGradient id="fill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#4f8cff" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#4f8cff" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#1c2744" vertical={false} />
            <XAxis dataKey="hour" stroke="#64748b" fontSize={12} />
            <YAxis stroke="#64748b" fontSize={12} />
            <Tooltip contentStyle={{ background: '#0e1526', border: '1px solid #1c2744', borderRadius: 8 }} />
            <Area type="monotone" dataKey="pressure" stroke="#2de2d0" strokeWidth={2} fill="url(#fill)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Panel>
  )
}
