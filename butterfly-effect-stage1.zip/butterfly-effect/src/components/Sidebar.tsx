import { LayoutDashboard, Map, Network, Eye, Undo2, Columns3, Flower2 } from 'lucide-react'
import type { View } from '../types'

const ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'map', label: 'Campus map', icon: Map },
  { id: 'network', label: 'Ripple network', icon: Network },
  { id: 'surprises', label: "What you didn't see coming", icon: Eye },
  { id: 'reverse', label: 'Reverse', icon: Undo2 },
  { id: 'compare', label: 'Compare', icon: Columns3 },
] as const

export default function Sidebar({ view, onChange }: { view: View; onChange: (v: View) => void }) {
  return (
    <nav className="flex shrink-0 flex-col gap-2 border-b border-edge bg-panel/80 p-3 backdrop-blur md:w-64 md:border-b-0 md:border-r md:p-5">
      <div className="flex items-center gap-3 px-2 py-1 md:mb-4">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-glow to-haze text-ink">
          <Flower2 size={20} />
        </span>
        <div>
          <div className="font-display text-lg font-semibold leading-tight">Butterfly Effect</div>
          <div className="text-xs text-slate-400">Decision simulation lab</div>
        </div>
      </div>
      <ul className="flex gap-1 overflow-x-auto md:flex-col md:overflow-visible">
        {ITEMS.map(({ id, label, icon: Icon }) => {
          const active = view === id
          return (
            <li key={id} className="shrink-0">
              <button
                onClick={() => onChange(id)}
                aria-current={active ? 'page' : undefined}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                  active
                    ? 'bg-glow/10 text-glow ring-1 ring-glow/30'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Icon size={17} />
                <span className="whitespace-nowrap">{label}</span>
              </button>
            </li>
          )
        })}
      </ul>
      <p className="mt-auto hidden px-2 pt-6 text-xs text-slate-500 md:block">Prototype v0.1 (Stage 1)</p>
    </nav>
  )
}
