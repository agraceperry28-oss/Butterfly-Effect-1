import Panel from './Panel'

const NODES = [
  { x: 40, y: 130, r: 14, c: '#2de2d0', label: 'Decision' },
  { x: 130, y: 70, r: 10, c: '#4f8cff', label: 'First order' },
  { x: 130, y: 190, r: 10, c: '#4f8cff', label: 'First order' },
  { x: 225, y: 40, r: 8, c: '#9b7bff', label: 'Second order' },
  { x: 225, y: 130, r: 8, c: '#9b7bff', label: 'Second order' },
  { x: 225, y: 215, r: 8, c: '#9b7bff', label: 'Second order' },
  { x: 305, y: 90, r: 6, c: '#c4b5fd', label: 'Third order' },
  { x: 305, y: 180, r: 6, c: '#c4b5fd', label: 'Third order' },
]
const LINKS = [[0, 1], [0, 2], [1, 3], [1, 4], [2, 4], [2, 5], [4, 6], [5, 7]]

export default function NetworkPlaceholder() {
  return (
    <Panel title="Ripple network" note="Live in Stage 3">
      <svg viewBox="0 0 340 260" className="w-full rounded-xl bg-ink" role="img" aria-label="Placeholder network of cascading consequences">
        {LINKS.map(([a, b], i) => (
          <line key={i} x1={NODES[a].x} y1={NODES[a].y} x2={NODES[b].x} y2={NODES[b].y}
            stroke="#4f8cff" strokeOpacity="0.5" strokeWidth="1.5" strokeDasharray="4 8" className="animate-dash" />
        ))}
        <circle cx={NODES[0].x} cy={NODES[0].y} r="14" fill="none" stroke="#2de2d0" strokeWidth="1.5"
          className="animate-ripple" style={{ transformOrigin: `${NODES[0].x}px ${NODES[0].y}px` }} />
        {NODES.map((n, i) => (
          <circle key={i} cx={n.x} cy={n.y} r={n.r} fill={n.c}>
            <title>{n.label}</title>
          </circle>
        ))}
      </svg>
    </Panel>
  )
}
