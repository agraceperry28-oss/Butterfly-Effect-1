import Panel from './Panel'

const LOTS = [
  { x: 60, y: 70, w: 90, h: 50, name: 'Demo Lot A' },
  { x: 210, y: 50, w: 80, h: 60, name: 'Demo Lot B' },
  { x: 120, y: 170, w: 100, h: 50, name: 'Demo Lot C' },
]

export default function MapPlaceholder() {
  return (
    <Panel title="Campus map" note="Interactive in Stage 2">
      <svg viewBox="0 0 340 260" className="w-full rounded-xl bg-ink" role="img" aria-label="Placeholder map with three demonstration parking lots">
        <defs>
          <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M20 0H0V20" fill="none" stroke="#1c2744" strokeWidth="0.6" />
          </pattern>
        </defs>
        <rect width="340" height="260" fill="url(#grid)" />
        <path d="M0 140 H340 M170 0 V260" stroke="#2a3a66" strokeWidth="8" />
        {LOTS.map((l) => (
          <g key={l.name}>
            <rect x={l.x} y={l.y} width={l.w} height={l.h} rx="6" fill="#2de2d0" fillOpacity="0.14" stroke="#2de2d0" strokeOpacity="0.6" />
            <text x={l.x + l.w / 2} y={l.y + l.h / 2 + 4} textAnchor="middle" fontSize="10" fill="#bfeee9">{l.name}</text>
          </g>
        ))}
      </svg>
    </Panel>
  )
}
